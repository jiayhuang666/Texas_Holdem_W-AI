To run the presentation offline: In windows: Click Presenting
				 In Mac: Click Prezi

If it is not working:
Link:
http://prezi.com/ydxxcmhrcgyg/?utm_campaign=share&utm_medium=copy&rc=ex0share